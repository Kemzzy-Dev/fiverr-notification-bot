// Function to send a Telegram notification using stored configuration.
function sendTelegramNotification(botToken, chatId, message) {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(message)}`;
  fetch(url)
    .then(response => response.json())
    .then(data => console.log("Telegram response:", data))
    .catch(error => console.error("Telegram error:", error));
}

// Function to send a browser notification.
function sendBrowserNotification(message) {
  if (Notification.permission === "granted") {
    new Notification("Fiverr Inbox Notifier", { body: message });
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        new Notification("Fiverr Inbox Notifier", { body: message });
      }
    });
  }
}

function getPublicIP() {
  return fetch("https://api.ipify.org?format=json")
    .then(response => response.json())
    .then(data => data.ip)
    .catch(error => {
      console.error("Error fetching public IP:", error);
      return "N/A";
    });
}

// Function that triggers a notification by fetching configuration from storage.
function triggerNotification() {
  chrome.storage.sync.get(
    [
      "telegramBotToken",
      "telegramChatId",
      "enableTelegram",
      "emailAddress",
      "smtpHost",
      "smtpUsername",
      "smtpPassword",
      "enableEmail",
      "enableBrowser"
    ],
    function (config) {
      // Get the public IP address first.
      getPublicIP().then(ip => {
        const message = `[${ip}] New Fiverr message detected!`;

        // Send Telegram notification if enabled and configured.
        if (config.enableTelegram && config.telegramBotToken && config.telegramChatId) {
          sendTelegramNotification(config.telegramBotToken, config.telegramChatId, message);
        } else if (config.enableTelegram) {
          console.warn("Telegram configuration not fully set.");
        }

        // Email notification is commented out; uncomment and configure if needed.
        // if (config.enableEmail && config.emailAddress && config.smtpHost && config.smtpUsername && config.smtpPassword) {
        //   sendEmailNotification(message, config);
        // } else if (config.enableEmail) {
        //   console.warn("Email configuration not fully set.");
        // }

        // Send browser notification if enabled.
        if (config.enableBrowser) {
          sendBrowserNotification(message);
        }

        console.log("Notification triggered:", message);
      });
    }
  );
}

// Utility function to check if a node (element or text) meets our conditions.
function elementMatchesCondition(node) {
  // If the node is a text node, check its data.
  if (node.nodeType === Node.TEXT_NODE) {
    if (node.data && node.data.includes("Just now")) {
      return true;
    }
  }
  // If it's an element node, check its text and computed color.
  else if (node.nodeType === Node.ELEMENT_NODE) {
    if (node.textContent && node.textContent.includes("Just now")) {
      return true;
    }
    const computedColor = window.getComputedStyle(node).color;
    if (computedColor === "rgb(193, 74, 131)") {
      return true;
    }
  }
  return false;
}

// Create a MutationObserver that listens for both added nodes and text changes.
const observer = new MutationObserver((mutationsList) => {
  mutationsList.forEach(mutation => {
    if (mutation.type === "childList") {
      // Check newly added nodes and all their descendants.
      mutation.addedNodes.forEach(node => {
        if (elementMatchesCondition(node)) {
          triggerNotification();
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          node.querySelectorAll("*").forEach(el => {
            if (elementMatchesCondition(el)) {
              triggerNotification();
            }
          });
        }
      });
    } else if (mutation.type === "characterData") {
      // If text content changes, check if the updated text meets the condition.
      if (elementMatchesCondition(mutation.target)) {
        triggerNotification();
      }
    }
  });
});

// Observe changes in child nodes, subtree, and text content changes.
observer.observe(document.body, { childList: true, subtree: true, characterData: true });

console.log("Fiverr Inbox Notifier is active and monitoring for new messages...");
