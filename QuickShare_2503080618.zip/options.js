document.addEventListener('DOMContentLoaded', function() {
    // Load stored settings when the options page is opened.
    chrome.storage.sync.get(
      [
        'telegramBotToken',
        'telegramChatId',
        'enableTelegram',
        'emailAddress',
        'smtpHost',
        'smtpUsername',
        'smtpPassword',
        'enableEmail',
        'enableBrowser'
      ],
      function(items) {
        document.getElementById('telegramBotToken').value = items.telegramBotToken || '';
        document.getElementById('telegramChatId').value = items.telegramChatId || '';
        document.getElementById('enableTelegram').checked = items.enableTelegram || false;
        document.getElementById('emailAddress').value = items.emailAddress || '';
        document.getElementById('smtpHost').value = items.smtpHost || '';
        document.getElementById('smtpUsername').value = items.smtpUsername || '';
        document.getElementById('smtpPassword').value = items.smtpPassword || '';
        document.getElementById('enableEmail').checked = items.enableEmail || false;
        document.getElementById('enableBrowser').checked = items.enableBrowser || false;
      }
    );
  
    // Save settings when the form is submitted.
    document.getElementById('settingsForm').addEventListener('submit', function(e) {
      e.preventDefault();
      var telegramBotToken = document.getElementById('telegramBotToken').value;
      var telegramChatId = document.getElementById('telegramChatId').value;
      var enableTelegram = document.getElementById('enableTelegram').checked;
      var emailAddress = document.getElementById('emailAddress').value;
      var smtpHost = document.getElementById('smtpHost').value;
      var smtpUsername = document.getElementById('smtpUsername').value;
      var smtpPassword = document.getElementById('smtpPassword').value;
      var enableEmail = document.getElementById('enableEmail').checked;
      var enableBrowser = document.getElementById('enableBrowser').checked;
      
      chrome.storage.sync.set({
        telegramBotToken: telegramBotToken,
        telegramChatId: telegramChatId,
        enableTelegram: enableTelegram,
        emailAddress: emailAddress,
        smtpHost: smtpHost,
        smtpUsername: smtpUsername,
        smtpPassword: smtpPassword,
        enableEmail: enableEmail,
        enableBrowser: enableBrowser
      }, function() {
        var status = document.getElementById('status');
        status.textContent = 'Settings saved!';
        setTimeout(function() {
          status.textContent = '';
        }, 2000);
      });
    });
  });
  